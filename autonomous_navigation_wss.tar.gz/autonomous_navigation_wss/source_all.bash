#! /bin/bash 
TURTLEBOT_DRIVERS_WS=~/autonomous_navigation_wss/turtlebot
TURTLEBOT_SIMULATION_WS=~/autonomous_navigation_wss/turtlebot_simulation
TURTLEBOT_INTERACTION_WS=~/autonomous_navigation_wss/turtlebot_interaction
TURTLEBOT_MAP_AND_NAV_WS=~/autonomous_navigation_wss/turtlebot_map_and_nav
TURTLEBOT_MSGS_WS=~/autonomous_navigation_wss/turtlebot_msgs
TURTLEBOT_2D_SLAM_WS=~/autonomous_navigation_wss/turtlebot_2dslam


source $TURTLEBOT_DRIVERS_WS/devel/setup.bash --extend
source $TURTLEBOT_SIMULATION_WS/devel/setup.bash --extend
source $TURTLEBOT_INTERACTION_WS/devel/setup.bash --extend
source $TURTLEBOT_MAP_AND_NAV_WS/devel/setup.bash --extend
source $TURTLEBOT_MSGS_WS/devel/setup.bash --extend
source $TURTLEBOT_2D_SLAM_WS/devel/setup.bash --extend


