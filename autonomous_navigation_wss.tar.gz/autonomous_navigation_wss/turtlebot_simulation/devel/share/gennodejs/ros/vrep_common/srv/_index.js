
"use strict";

let simRosLoadModel = require('./simRosLoadModel.js')
let simRosEnableSubscriber = require('./simRosEnableSubscriber.js')
let simRosPauseSimulation = require('./simRosPauseSimulation.js')
let simRosLoadScene = require('./simRosLoadScene.js')
let simRosSetJointPosition = require('./simRosSetJointPosition.js')
let simRosGetCollectionHandle = require('./simRosGetCollectionHandle.js')
let simRosGetVisionSensorImage = require('./simRosGetVisionSensorImage.js')
let simRosReadForceSensor = require('./simRosReadForceSensor.js')
let simRosGetFloatSignal = require('./simRosGetFloatSignal.js')
let simRosClearFloatSignal = require('./simRosClearFloatSignal.js')
let simRosReadDistance = require('./simRosReadDistance.js')
let simRosGetIntegerParameter = require('./simRosGetIntegerParameter.js')
let simRosGetUIEventButton = require('./simRosGetUIEventButton.js')
let simRosSetBooleanParameter = require('./simRosSetBooleanParameter.js')
let simRosGetObjectFloatParameter = require('./simRosGetObjectFloatParameter.js')
let simRosSetArrayParameter = require('./simRosSetArrayParameter.js')
let simRosGetInfo = require('./simRosGetInfo.js')
let simRosGetObjectSelection = require('./simRosGetObjectSelection.js')
let simRosCreateDummy = require('./simRosCreateDummy.js')
let simRosCallScriptFunction = require('./simRosCallScriptFunction.js')
let simRosSetIntegerSignal = require('./simRosSetIntegerSignal.js')
let simRosRemoveObject = require('./simRosRemoveObject.js')
let simRosCloseScene = require('./simRosCloseScene.js')
let simRosClearStringSignal = require('./simRosClearStringSignal.js')
let simRosAuxiliaryConsoleClose = require('./simRosAuxiliaryConsoleClose.js')
let simRosSetJointTargetVelocity = require('./simRosSetJointTargetVelocity.js')
let simRosGetIntegerSignal = require('./simRosGetIntegerSignal.js')
let simRosAuxiliaryConsoleOpen = require('./simRosAuxiliaryConsoleOpen.js')
let simRosSynchronous = require('./simRosSynchronous.js')
let simRosGetObjectPose = require('./simRosGetObjectPose.js')
let simRosRemoveUI = require('./simRosRemoveUI.js')
let simRosGetArrayParameter = require('./simRosGetArrayParameter.js')
let simRosGetObjects = require('./simRosGetObjects.js')
let simRosGetDistanceHandle = require('./simRosGetDistanceHandle.js')
let simRosGetLastErrors = require('./simRosGetLastErrors.js')
let simRosStopSimulation = require('./simRosStopSimulation.js')
let simRosGetModelProperty = require('./simRosGetModelProperty.js')
let simRosStartSimulation = require('./simRosStartSimulation.js')
let simRosSetObjectQuaternion = require('./simRosSetObjectQuaternion.js')
let simRosReadVisionSensor = require('./simRosReadVisionSensor.js')
let simRosEnablePublisher = require('./simRosEnablePublisher.js')
let simRosSetUISlider = require('./simRosSetUISlider.js')
let simRosSetObjectIntParameter = require('./simRosSetObjectIntParameter.js')
let simRosGetCollisionHandle = require('./simRosGetCollisionHandle.js')
let simRosGetFloatingParameter = require('./simRosGetFloatingParameter.js')
let simRosSetObjectParent = require('./simRosSetObjectParent.js')
let simRosSetModelProperty = require('./simRosSetModelProperty.js')
let simRosSetSphericalJointMatrix = require('./simRosSetSphericalJointMatrix.js')
let simRosSetFloatingParameter = require('./simRosSetFloatingParameter.js')
let simRosGetUIButtonProperty = require('./simRosGetUIButtonProperty.js')
let simRosEraseFile = require('./simRosEraseFile.js')
let simRosGetDialogInput = require('./simRosGetDialogInput.js')
let simRosSetObjectPosition = require('./simRosSetObjectPosition.js')
let simRosGetObjectGroupData = require('./simRosGetObjectGroupData.js')
let simRosAuxiliaryConsoleShow = require('./simRosAuxiliaryConsoleShow.js')
let simRosGetJointMatrix = require('./simRosGetJointMatrix.js')
let simRosAddStatusbarMessage = require('./simRosAddStatusbarMessage.js')
let simRosDisplayDialog = require('./simRosDisplayDialog.js')
let simRosSetObjectPose = require('./simRosSetObjectPose.js')
let simRosSetFloatSignal = require('./simRosSetFloatSignal.js')
let simRosAppendStringSignal = require('./simRosAppendStringSignal.js')
let simRosDisablePublisher = require('./simRosDisablePublisher.js')
let simRosEndDialog = require('./simRosEndDialog.js')
let simRosCopyPasteObjects = require('./simRosCopyPasteObjects.js')
let simRosSetObjectFloatParameter = require('./simRosSetObjectFloatParameter.js')
let simRosSetUIButtonProperty = require('./simRosSetUIButtonProperty.js')
let simRosAuxiliaryConsolePrint = require('./simRosAuxiliaryConsolePrint.js')
let simRosClearIntegerSignal = require('./simRosClearIntegerSignal.js')
let simRosBreakForceSensor = require('./simRosBreakForceSensor.js')
let simRosGetStringSignal = require('./simRosGetStringSignal.js')
let simRosSetUIButtonLabel = require('./simRosSetUIButtonLabel.js')
let simRosSetVisionSensorImage = require('./simRosSetVisionSensorImage.js')
let simRosSetJointState = require('./simRosSetJointState.js')
let simRosDisableSubscriber = require('./simRosDisableSubscriber.js')
let simRosReadProximitySensor = require('./simRosReadProximitySensor.js')
let simRosLoadUI = require('./simRosLoadUI.js')
let simRosRemoveModel = require('./simRosRemoveModel.js')
let simRosGetJointState = require('./simRosGetJointState.js')
let simRosGetUIHandle = require('./simRosGetUIHandle.js')
let simRosGetObjectParent = require('./simRosGetObjectParent.js')
let simRosGetObjectChild = require('./simRosGetObjectChild.js')
let simRosGetAndClearStringSignal = require('./simRosGetAndClearStringSignal.js')
let simRosReadCollision = require('./simRosReadCollision.js')
let simRosSetObjectSelection = require('./simRosSetObjectSelection.js')
let simRosGetObjectIntParameter = require('./simRosGetObjectIntParameter.js')
let simRosGetBooleanParameter = require('./simRosGetBooleanParameter.js')
let simRosSetIntegerParameter = require('./simRosSetIntegerParameter.js')
let simRosSetJointTargetPosition = require('./simRosSetJointTargetPosition.js')
let simRosGetUISlider = require('./simRosGetUISlider.js')
let simRosGetObjectHandle = require('./simRosGetObjectHandle.js')
let simRosSetStringSignal = require('./simRosSetStringSignal.js')
let simRosSynchronousTrigger = require('./simRosSynchronousTrigger.js')
let simRosGetDialogResult = require('./simRosGetDialogResult.js')
let simRosTransferFile = require('./simRosTransferFile.js')
let simRosGetStringParameter = require('./simRosGetStringParameter.js')
let simRosSetJointForce = require('./simRosSetJointForce.js')
let simRosGetVisionSensorDepthBuffer = require('./simRosGetVisionSensorDepthBuffer.js')

module.exports = {
  simRosLoadModel: simRosLoadModel,
  simRosEnableSubscriber: simRosEnableSubscriber,
  simRosPauseSimulation: simRosPauseSimulation,
  simRosLoadScene: simRosLoadScene,
  simRosSetJointPosition: simRosSetJointPosition,
  simRosGetCollectionHandle: simRosGetCollectionHandle,
  simRosGetVisionSensorImage: simRosGetVisionSensorImage,
  simRosReadForceSensor: simRosReadForceSensor,
  simRosGetFloatSignal: simRosGetFloatSignal,
  simRosClearFloatSignal: simRosClearFloatSignal,
  simRosReadDistance: simRosReadDistance,
  simRosGetIntegerParameter: simRosGetIntegerParameter,
  simRosGetUIEventButton: simRosGetUIEventButton,
  simRosSetBooleanParameter: simRosSetBooleanParameter,
  simRosGetObjectFloatParameter: simRosGetObjectFloatParameter,
  simRosSetArrayParameter: simRosSetArrayParameter,
  simRosGetInfo: simRosGetInfo,
  simRosGetObjectSelection: simRosGetObjectSelection,
  simRosCreateDummy: simRosCreateDummy,
  simRosCallScriptFunction: simRosCallScriptFunction,
  simRosSetIntegerSignal: simRosSetIntegerSignal,
  simRosRemoveObject: simRosRemoveObject,
  simRosCloseScene: simRosCloseScene,
  simRosClearStringSignal: simRosClearStringSignal,
  simRosAuxiliaryConsoleClose: simRosAuxiliaryConsoleClose,
  simRosSetJointTargetVelocity: simRosSetJointTargetVelocity,
  simRosGetIntegerSignal: simRosGetIntegerSignal,
  simRosAuxiliaryConsoleOpen: simRosAuxiliaryConsoleOpen,
  simRosSynchronous: simRosSynchronous,
  simRosGetObjectPose: simRosGetObjectPose,
  simRosRemoveUI: simRosRemoveUI,
  simRosGetArrayParameter: simRosGetArrayParameter,
  simRosGetObjects: simRosGetObjects,
  simRosGetDistanceHandle: simRosGetDistanceHandle,
  simRosGetLastErrors: simRosGetLastErrors,
  simRosStopSimulation: simRosStopSimulation,
  simRosGetModelProperty: simRosGetModelProperty,
  simRosStartSimulation: simRosStartSimulation,
  simRosSetObjectQuaternion: simRosSetObjectQuaternion,
  simRosReadVisionSensor: simRosReadVisionSensor,
  simRosEnablePublisher: simRosEnablePublisher,
  simRosSetUISlider: simRosSetUISlider,
  simRosSetObjectIntParameter: simRosSetObjectIntParameter,
  simRosGetCollisionHandle: simRosGetCollisionHandle,
  simRosGetFloatingParameter: simRosGetFloatingParameter,
  simRosSetObjectParent: simRosSetObjectParent,
  simRosSetModelProperty: simRosSetModelProperty,
  simRosSetSphericalJointMatrix: simRosSetSphericalJointMatrix,
  simRosSetFloatingParameter: simRosSetFloatingParameter,
  simRosGetUIButtonProperty: simRosGetUIButtonProperty,
  simRosEraseFile: simRosEraseFile,
  simRosGetDialogInput: simRosGetDialogInput,
  simRosSetObjectPosition: simRosSetObjectPosition,
  simRosGetObjectGroupData: simRosGetObjectGroupData,
  simRosAuxiliaryConsoleShow: simRosAuxiliaryConsoleShow,
  simRosGetJointMatrix: simRosGetJointMatrix,
  simRosAddStatusbarMessage: simRosAddStatusbarMessage,
  simRosDisplayDialog: simRosDisplayDialog,
  simRosSetObjectPose: simRosSetObjectPose,
  simRosSetFloatSignal: simRosSetFloatSignal,
  simRosAppendStringSignal: simRosAppendStringSignal,
  simRosDisablePublisher: simRosDisablePublisher,
  simRosEndDialog: simRosEndDialog,
  simRosCopyPasteObjects: simRosCopyPasteObjects,
  simRosSetObjectFloatParameter: simRosSetObjectFloatParameter,
  simRosSetUIButtonProperty: simRosSetUIButtonProperty,
  simRosAuxiliaryConsolePrint: simRosAuxiliaryConsolePrint,
  simRosClearIntegerSignal: simRosClearIntegerSignal,
  simRosBreakForceSensor: simRosBreakForceSensor,
  simRosGetStringSignal: simRosGetStringSignal,
  simRosSetUIButtonLabel: simRosSetUIButtonLabel,
  simRosSetVisionSensorImage: simRosSetVisionSensorImage,
  simRosSetJointState: simRosSetJointState,
  simRosDisableSubscriber: simRosDisableSubscriber,
  simRosReadProximitySensor: simRosReadProximitySensor,
  simRosLoadUI: simRosLoadUI,
  simRosRemoveModel: simRosRemoveModel,
  simRosGetJointState: simRosGetJointState,
  simRosGetUIHandle: simRosGetUIHandle,
  simRosGetObjectParent: simRosGetObjectParent,
  simRosGetObjectChild: simRosGetObjectChild,
  simRosGetAndClearStringSignal: simRosGetAndClearStringSignal,
  simRosReadCollision: simRosReadCollision,
  simRosSetObjectSelection: simRosSetObjectSelection,
  simRosGetObjectIntParameter: simRosGetObjectIntParameter,
  simRosGetBooleanParameter: simRosGetBooleanParameter,
  simRosSetIntegerParameter: simRosSetIntegerParameter,
  simRosSetJointTargetPosition: simRosSetJointTargetPosition,
  simRosGetUISlider: simRosGetUISlider,
  simRosGetObjectHandle: simRosGetObjectHandle,
  simRosSetStringSignal: simRosSetStringSignal,
  simRosSynchronousTrigger: simRosSynchronousTrigger,
  simRosGetDialogResult: simRosGetDialogResult,
  simRosTransferFile: simRosTransferFile,
  simRosGetStringParameter: simRosGetStringParameter,
  simRosSetJointForce: simRosSetJointForce,
  simRosGetVisionSensorDepthBuffer: simRosGetVisionSensorDepthBuffer,
};
